#!/usr/bin/env python
# coding: utf-8

import numpy as np
import matplotlib.pyplot as plt

from scipy.signal import butter, lfilter, resample, hilbert, ricker, decimate
from FastFourierTransform import __fast_fourier_transform

def __create_synthetic_event(T, sps, w, offset, noise=True):
    
    '''
    creating a transient event signal by combining ricker wavelets, which is subsequently modulated onto the carrier signal
    
    T         = total time of trace
    sps       = samples per second corresponding to anlog signal
    w         = dominant width of ricker wavelet
    noise     = True/False , to either include or exclude noise for the event signal
    '''
    
    ## shift the transient signal along the trace in time dimension
#     offset = 50
    
    ## arbitray length
    Npts = int(sps*2)
    
    ## time axis
    time = np.arange(0, Npts/sps, 1/sps)
    
    spikes = np.array([1,5,4,8,15,17,70,72,75,79,85]) * int(np.ceil(Npts/200))  + offset

    ref = np.zeros(Npts)
    rick = ricker(Npts, w)

    for i in spikes:
        ref[i] = 1
        
    if noise:        
        noise = np.random.rand(Npts)
        event = np.convolve(rick, ref, 'same') + 0.1 * noise
    else:
        event = np.convolve(rick, ref, 'same')

    
    event_fft, ff = __fast_fourier_transform(event, 1/sps)
    #event_fft_db = 20*np.log10(event_fft/max(event_fft))
    
    
    ## _______________________________________________________________________________
    ## Plotting 
    
    fig, (ax1, ax2) = plt.subplots(1,2,figsize=(15,5))

    N = int(ff.size)
    

    ax1.plot(time, event,color='black')
    
    ax2.plot(ff[:N // 2],np.abs(event_fft[:N // 2]))

#     ax1.set_xlim(min(spikes)/sps-0.1*min(spikes)/sps,max(spikes)/sps+0.1*max(spikes)/sps)
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Counts')
    
#     ax2.set_xlim(0, 200/w)
#     ax2.set_ylim(0,max(np.abs(event_fft[10:N // 2]))+0.01*max(np.abs(event_fft[:N // 2])))
    ax2.set_xlabel('Frequency (Hz)')
    ax2.set_ylabel('Spectral Amplitude')
    
    plt.show();
    
    return time, event

#     ## set width of ricker wavelet and shift
#     width = 40
#     shift = 700 
    
#     ## get synthetic generated trace using ricker wavelets
#     time_modeltrace, modeltrace = __create_synthetic_event(T, sps, width, shift, noise=True)
    
    
#     ## convert arrays to traces
#     time_modeltrace = obspy.core.trace.Trace(time_modeltrace)
#     modeltrace = obspy.core.trace.Trace(modeltrace)

#     ## set correct sampling for both traces
#     modeltrace.stats.delta = (T+2/sps)/modeltrace.stats.npts
#     time_modeltrace.stats.delta = (T+2/sps)/time_modeltrace.stats.npts
    
#     ## interpolate traces
#     modeltrace_interpol = modeltrace.resample(sampling_rate = sps)
#     time_modeltrace_interpol = time_modeltrace.resample(sampling_rate = sps)
# #     modeltrace_interpol, time_modeltrace_interpol = __interpolation(modeltrace, time_modeltrace, sps)
