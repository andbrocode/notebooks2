#!/usr/bin/env python
# coding: utf-8

import numpy as np

def __modulation(f_sgnc, data , T, sps, case=1):
    
    option = 1
    
    
    ## option 1 -- interpolate event trace
    if option == 1:
        print(f"Option {option} is set: interpolation of event")
        timeline = np.linspace(0, T, T*sps+1)

#         data.interpolate(sampling_rate = sps)
        
        event = np.array(data)
        if len(event) != len(timeline):
            print(f"Difference in lengths: event = {len(event)} and timeline ={len(timeline)}")
        
        
    
    ## option 2 -- expand event symetrically with zeros
    if option == 2:
        print(f"Option {option} is set: extending event with zeros")
        
        event = np.array(data)
        
        timeline = np.arange(0, T+1/sps, 1/sps)
        
        if len(event) < len(timeline):
            diff_pts = len(timeline) - len(event)

            event = np.concatenate(
                (np.zeros(int(diff_pts/2)),
                 event,
                 np.zeros(diff_pts-int(diff_pts/2))),axis=0)

            if len(event) != len(timeline):
                print("still some error with event and time length!")

        
    if case == 1:
        print(f"Case {icase} is set: old modulation scheme")

        factor = 0.1
        sig_ana = np.sin(2*np.pi*(f_sgnc + factor * event) * timeline) 
        
        return sig_ana, event, timeline
    
    if case == 2:
        
        
        return sig_ana, event, timeline
