#!/usr/bin/env python
# coding: utf-8

import matplotlib.pyplot as plt

def __makeplot_modulated_signal(sig, tt):
    
    font = 13

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15,5))

    ax1.plot(tt,sig, color="grey")

    ax2.plot(tt,sig, color="grey")
    ax2.scatter(tt, sig, color="black", s=10)

    ax1.tick_params(axis='both', labelsize=font)
    ax2.tick_params(axis='both', labelsize=font)
    
    ax1.set_xlabel('Time (s)', fontsize=font)
    ax1.set_ylabel('Amplitude', fontsize=font)

    ax2.set_xlabel('Time (s)', fontsize=font)
    ax2.set_ylabel('Amplitude', fontsize=font)
    
    ax2.set_xlim(0,200*(tt[1]-tt[0]))
    
    ax1.axvspan(0,200*(tt[1]-tt[0]), color='r', zorder=3)
    
    plt.show();

    return fig