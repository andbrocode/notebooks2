#!/usr/bin/env python
# coding: utf-8

import matplotlib.pyplot as plt


def __makeplot_compare_schemes(sig1, time1, sig2, time2, number_of_samples=100):
    
    if time1.size != time2.size:
        print("array size does not match!")
    
    ## __________________________________________________________
    ##
    
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(15,5))

    font = 13 
    num = number_of_samples
    
    ax1.plot(time1[:num], sig1[:num])
    ax1.scatter(time1[:num], sig1[:num], s=10)
    
    ax1.plot(time1[:num], sig2[:num])
    ax1.scatter(time1[:num], sig2[:num], s=10)

    
    ax2.plot(time1[:num], sig1[:num]-sig2[:num],'grey')
    ax2.scatter(time1[:num], sig1[:num]-sig2[:num], s=10, c='k')

    ax3.plot(time1, sig1-sig2,'grey')
    
    ax2.set_xlabel("Time (s)", fontsize=font)
    
#     ax2.set_ylim(-1,1)
    
    plt.show();
    
    return fig
