#!/usr/bin/env python
# coding: utf-8

import matplotlib.pyplot as plt

from FastFourierTransform import __fast_fourier_transform
from numpy import arange, abs



def __makeplot_trace_and_spectrum(trace, timeline, fmax=None):
    
    font = 13
    
    N = len(trace)
    
    if timeline is None:
        delta = 1/sps
        timeline = arange(0, N/sps, 1/sps)
    else:
        if str(type(trace)) == "<class 'obspy.core.trace.Trace'>": 
            delta = trace.stats.delta
        else:
            delta = timeline[1]-timeline[0]
    
    
    ## __________________________________________________________
    ##
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15,5))

    trace_fft, ff = __fast_fourier_transform(signal_in=trace, dt=delta , window=None, normalize=None)

    ax1.plot(timeline, trace)

    ax2.plot(ff[:N // 2],abs(trace_fft[:N // 2]))
    
    ax1.set_xlabel("Time (s)", fontsize=font)
    ax1.set_ylabel(r"Amplitude $\frac{rad}{s}$", fontsize=font)
    
    ax2.set_xlabel("Frequency (Hz)", fontsize=font)
    ax2.set_ylabel(r"Amplitude Spectral Density ($\frac{rad}{s \sqrt{Hz} }$)", fontsize=font)
    
    if fmax:
        ax2.set_xlim(0, fmax)
    
    plt.show();
    
    return fig
