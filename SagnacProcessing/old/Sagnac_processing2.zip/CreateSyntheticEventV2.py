#!/usr/bin/env python
# coding: utf-8

import random
from scipy.signal import ricker, resample
from numpy import zeros, random, convolve, arange, kaiser, hamming
from MakeplotTraceAndSpectrum import __makeplot_trace_and_spectrum


def __create_synthetic_event_v2(fc, T, sps, noise=False, padding=None):

    ## reduce the ull window due to efficiency
    Npts = int(T*sps/10)


    ## define a ricker wavelet
    n = 1e3/fc
    rick = ricker(n, n/10)


    ## define random locations 
    locations = zeros(Npts)

    ## exclude edges to avoid edge effects 
    k = int(Npts/20)
    
    for i in range(k):
        if padding is not None:
            border = padding 
        else:
            border = k 
            
        n = random.randint(border,int(Npts-border))
        locations[n] = 1

    ## convolve ricker wavelet with locations 
    if noise:        
        noise = random.rand(Npts)
        event = convolve(rick, locations, 'same') + 0.01 * noise
    else:
        event = convolve(rick, locations, 'same')

    ## time axis for event (for resample)
    time_event = arange(0, Npts/sps, 1/sps)

    ## time axis as it should be (for resample)
    timeline = arange(0,T+1/sps,1/sps)


    ## resample to acutal sampling rate (= sps) and apply taper
#     event_new = resample(event, int(timeline.size)) * hamming(int(timeline.size))
    event_new = resample(event, int(timeline.size)) * kaiser(int(timeline.size), 8.6)


    ## show the created trace and spectrum                          
#     __makeplot_trace_and_spectrum(event_new[::100], timeline[::100], fmax=10*fc);
    
    return event_new, timeline